package com.boa.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.boa.entity.Admin;
import com.boa.entity.Book;
import com.boa.entity.Professor;

@Repository
public interface AdminRepository extends JpaRepository<Admin, Long> {
	// Crete / Update // delete / List operation

	// Cutome // JPQL
}
