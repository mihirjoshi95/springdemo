package com.boa.restcontroller;

public class PaymentController {

}
